"""Reproduce the V10 revision analyses. Python 3.12; see requirements.txt.
Run: python analysis_v10.py --data analysis_data.csv --out results --blrt 199
The deidentified CSV contains only analytical variables; no free text or identifiers.
"""
import os
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
import sys, json, argparse, time
from pathlib import Path
local=Path(__file__).parent/'pydeps'
if local.exists(): sys.path.insert(0,str(local))
import numpy as np
import pandas as pd
import scipy
from scipy.special import logsumexp, expit, softmax
from scipy.optimize import minimize, brentq
from scipy.stats import spearmanr, norm, chi2
import statsmodels.api as sm
from statsmodels.tools.numdiff import approx_hess
from sklearn.decomposition import PCA
from threadpoolctl import threadpool_limits
threadpool_limits(1)
ITEMS=['annual_exam','consultation','equipment','planning','weather','knowledge','supplies','training']
LEVELS=[2,2,4,4,4,4,4,3]
NAMES=['Intercept','EBI per 10','Comprehensive vs minimal','Selective vs minimal','Age categories 4-5 vs 1-3','Age category 6 vs 1-3','Female vs male','BMI per 5','Experience per category','Mountaineering']

def read_data(p):
 if str(p).endswith('.csv'): return pd.read_csv(p)
 from openpyxl import load_workbook
 rows=list(load_workbook(p,read_only=True,data_only=True).active.values)[1:]
 a=np.array([[float(x) if x is not None and isinstance(x,(int,float)) else np.nan for x in r] for r in rows])
 d=pd.DataFrame({'sex':a[:,1],'age':a[:,2],'bmi':a[:,4]/(a[:,3]/100)**2,'occupation':a[:,5],
  'hiking':a[:,6],'mountaineering':a[:,7],'running':a[:,8],'cycling':a[:,9],'ball_sports':a[:,10],
  'other_activity':a[:,11],'frequency':a[:,12],'duration':a[:,13],'distance':a[:,14],
  'experience':a[:,15],'injury':(a[:,16]==1).astype(int),'injury_episodes':a[:,27]})
 for j,k in enumerate(ITEMS): d[k]=a[:,29+j]
 return d

def onehot(a):
 return np.concatenate([(a[:,j,None]==np.arange(c)[None,:]).astype(float) for j,c in enumerate(LEVELS)],axis=1)

def lca(a,k,starts=120,seed=20261104,maxiter=4000,tol=1e-7,initial=None):
 """Batched multi-start EM for independent multinomial indicators. Absolute LL tolerance."""
 rng=np.random.default_rng(seed); x=onehot(a); n,d=x.shape; s=starts
 theta=np.concatenate([rng.dirichlet(np.ones(c),size=(s,k)) for c in LEVELS],axis=2)
 pi=rng.dirichlet(np.ones(k),size=s)
 if initial is not None:
  theta[0],pi[0]=initial
 last=np.full(s,-np.inf); done=np.zeros(s,bool)
 for it in range(maxiter):
  joint=(x@np.log(np.maximum(theta,1e-14)).reshape(s*k,d).T).reshape(n,s,k).transpose(1,0,2)+np.log(np.maximum(pi,1e-14))[:,None,:]
  den=logsumexp(joint,axis=2); ll=den.sum(axis=1); tau=np.exp(joint-den[:,:,None])
  changed=np.abs(ll-last); done|=(changed<tol)
  if done.all(): break
  counts=tau.transpose(0,2,1).reshape(s*k,n)@x
  counts=counts.reshape(s,k,d)+1e-12
  offset=0
  new=counts.copy()
  for c in LEVELS:
   new[:,:,offset:offset+c]/=counts[:,:,offset:offset+c].sum(axis=2,keepdims=True);offset+=c
  newpi=tau.mean(axis=1)
  theta=np.where(done[:,None,None],theta,new);pi=np.where(done[:,None],pi,newpi)
  last=ll
 best=int(np.argmax(ll));b=ll[best];t=tau[best]; lab=t.argmax(1)
 return {'ll':float(b),'theta':theta[best],'pi':pi[best],'tau':t,'labels':lab,
 'repeated':int(np.sum(np.abs(ll-b)<1e-4)),'iterations':it+1,'converged':bool(done[best]),
 'all_ll':ll,'entropy':float(1+np.sum(t*np.log(np.maximum(t,1e-15)))/(n*np.log(k))) if k>1 else 1,
 'avepp':[float(t[lab==c,c].mean()) if (lab==c).any() else np.nan for c in range(k)]}

def order_lca(f):
 # Mean probability of the descriptive high-preparedness response, not used to fit LCA.
 th=f['theta']; offset=0; score=np.zeros(len(th))
 for j,c in enumerate(LEVELS):
  score+=th[:,offset:offset+(1 if j in [0,1,7] else 2)].sum(1);offset+=c
 order=np.argsort(-score); f['theta']=th[order];f['pi']=f['pi'][order];f['tau']=f['tau'][:,order]
 f['labels']=f['tau'].argmax(1)
 f['avepp']=[float(f['tau'][f['labels']==c,c].mean()) for c in range(len(th))]
 return f

def estimates(res,names):
 b=np.asarray(res.params);se=np.asarray(res.bse);p=np.asarray(res.pvalues)
 return {n:{'estimate':float(np.exp(v)),'lo':float(np.exp(v-1.96*s)),'hi':float(np.exp(v+1.96*s)),'p':float(pv)} for n,v,s,pv in zip(names,b,se,p)}

def firth(X,y):
 def value_score(b):
  eta=X@b;p=expit(eta);w=p*(1-p);info=X.T@(w[:,None]*X)
  sign,ld=np.linalg.slogdet(info)
  if sign<=0: return -np.inf,np.zeros(X.shape[1])
  h=w*np.einsum('ij,jk,ik->i',X,np.linalg.inv(info),X)
  val=np.sum(y*eta-np.logaddexp(0,eta))+ld/2
  score=X.T@(y-p+h*(0.5-p))
  return val,score
 start=sm.Logit(y,X).fit(disp=0).params
 opt=minimize(lambda b:-value_score(b)[0],start,jac=lambda b:-value_score(b)[1],method='BFGS',options={'gtol':1e-8,'maxiter':2000})
 b=opt.x;v=value_score(b)[0]; out={}
 for j,name in enumerate(NAMES):
  if j==0: continue
  ix=np.arange(len(b))!=j
  def profile(c):
   def pack(z):
    zfull=b.copy();zfull[j]=c;zfull[ix]=z;return zfull
   f=minimize(lambda z:-value_score(pack(z))[0],b[ix],jac=lambda z:-value_score(pack(z))[1][ix],method='BFGS',options={'gtol':1e-7,'maxiter':1000})
   return -f.fun
  target=v-chi2.ppf(.95,1)/2
  roots=[]
  for direction in [-1,1]:
   delta=.5
   while profile(b[j]+direction*delta)>target and delta<30:delta*=2
   roots.append(brentq(lambda c:profile(c)-target,*sorted([b[j],b[j]+direction*delta]),xtol=1e-7))
  out[name]={'estimate':float(np.exp(b[j])),'lo':float(np.exp(roots[0])),'hi':float(np.exp(roots[1])),'p':float(chi2.sf(2*(v-profile(0)),1))}
 return out,{'max_abs_score':float(np.max(np.abs(value_score(b)[1]))),'converged':bool(np.max(np.abs(value_score(b)[1]))<1e-5)}

def ml_three_step(d,f,Z,X,y):
 """Vermunt ML three-step: fixed P(modal assignment | latent class), joint P(W,Y | Z).
 Multinomial membership model includes all non-class outcome covariates. Conditional
 observed-information SEs treat the first-step measurement estimates as fixed.
 """
 tau=f['tau'];labels=f['labels'];n=len(y);k=3;q=Z.shape[1]
 D=np.stack([tau[labels==w].sum(0)/tau.sum(0) for w in range(k)])
 dw=np.log(np.maximum(D[labels],1e-14))
 # C=2 minimal reference, separate outcome intercepts expressed as class contrasts.
 B=np.stack([np.column_stack([Z,np.full(n,c==0),np.full(n,c==1)]) for c in range(k)],axis=1)
 # B has all nonclass predictors, then comprehensive and selective effects.
 b0=sm.Logit(y,X).fit(disp=0).params
 beta=np.r_[b0[0:2],b0[4:],b0[2:4]]
 gamma=np.zeros((2,q));gamma[:,0]=np.log(f['pi'][:2]/f['pi'][2])
 def fun_grad(par):
  be=par[:q+2];ga=par[q+2:].reshape(2,q)
  logits=np.column_stack([Z@ga.T,np.zeros(n)]);lc=logits-logsumexp(logits,axis=1)[:,None];pc=np.exp(lc)
  eta=B@be;pr=expit(eta);ly=y[:,None]*eta-np.logaddexp(0,eta)
  lj=lc+dw+ly;ld=logsumexp(lj,axis=1);post=np.exp(lj-ld[:,None])
  gb=np.einsum('nk,nkp->p',post*(y[:,None]-pr),B)
  gg=(post[:,:2]-pc[:,:2]).T@Z
  return -ld.sum(),-np.r_[gb,gg.ravel()]
 opt=minimize(lambda par:fun_grad(par),np.r_[beta,gamma.ravel()],jac=True,method='BFGS',options={'gtol':1e-7,'maxiter':5000})
 H=approx_hess(opt.x,lambda par:fun_grad(par)[0]);cov=np.linalg.inv(H);se=np.sqrt(np.diag(cov))
 bn=['Intercept','EBI per 10']+NAMES[4:]+NAMES[2:4]
 out={name:{'estimate':float(np.exp(b)),'lo':float(np.exp(b-1.96*s)),'hi':float(np.exp(b+1.96*s)),'p':float(2*norm.sf(abs(b/s)))} for name,b,s in zip(bn,opt.x[:q+2],se[:q+2])}
 return out,{'D':D,'max_abs_score':float(np.max(np.abs(fun_grad(opt.x)[1]))),'hessian_min_eigenvalue':float(np.linalg.eigvalsh(H).min()),'parameters':len(opt.x),'conditional_se':True}

def jsondefault(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 raise TypeError(type(x).__name__)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--data',required=True);ap.add_argument('--out',default='results');ap.add_argument('--blrt',type=int,default=199);ap.add_argument('--bootstrap-starts',type=int,default=20);args=ap.parse_args()
 out=Path(args.out);out.mkdir(parents=True,exist_ok=True);d=read_data(args.data);d.to_csv(out/'analysis_data.csv',index=False)
 assert len(d)==220 and d.injury.sum()==81
 assert not d[['sex','age','bmi','frequency','duration','distance','experience','injury']+ITEMS].isna().any().any()
 assert d.age.isin(range(1,7)).all() and d.sex.isin([1,2]).all()
 for col,c in zip(ITEMS,LEVELS):assert d[col].isin(range(1,c+1)).all()
 e=np.column_stack([(d.frequency-1)/4,(d.duration-1)/3,(d.distance-1)/4]);ebi=e.mean(1)*100;y=d.injury.to_numpy()
 a=d[ITEMS].to_numpy(dtype=int)-1
 results={'n':len(d),'events':int(y.sum()),'versions':{'Python':sys.version.split()[0],'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'statsmodels':sm.__version__},'correlations':{}}
 for c1,c2 in [('frequency','duration'),('frequency','distance'),('duration','distance')]:
  r=spearmanr(d[c1],d[c2]);results['correlations'][c1+'_'+c2]={'rho':r.statistic,'p':r.pvalue}
 fits={}
 for k in range(1,6):
  t=time.time();f=lca(a,k,seed=20261104+k);fits[k]=order_lca(f) if k>1 else f
  p=k*19+k-1
  results.setdefault('lca',{})[k]={'ll':f['ll'],'parameters':p,'AIC':-2*f['ll']+2*p,'BIC':-2*f['ll']+np.log(len(d))*p,'aBIC':-2*f['ll']+np.log((len(d)+2)/24)*p,'entropy':f['entropy'],'repeated':f['repeated'],'iterations':f['iterations'],'converged':f['converged'],'counts':np.bincount(f['labels'],minlength=k),'avepp':f['avepp'],'theta':f['theta'],'pi':f['pi']}
  print('LCA',k,results['lca'][k]['ll'],'repeated',f['repeated'],'seconds',round(time.time()-t,1),flush=True)
 f=fits[3];cls=f['labels'];d['class']=cls;d['ebi']=ebi
 np.savez_compressed(out/'lca_models.npz',**{f'{key}_{k}':fits[k][key] for k in fits for key in ['theta','pi','tau','labels','all_ll']})
 Z=np.column_stack([np.ones(len(d)),ebi/10,(d.age.isin([4,5])).astype(int),(d.age==6).astype(int),(d.sex==2).astype(int),d.bmi/5,d.experience,d.mountaineering])
 X=np.column_stack([Z[:,:2],cls==0,cls==1,Z[:,2:]])
 results['logit']={}
 for name,xx,nn in [('Model 1',X[:,:2],NAMES[:2]),('Model 2',X[:,:4],NAMES[:4]),('Model 3',X,NAMES)]:
  res=sm.Logit(y,xx).fit(disp=0);results['logit'][name]=estimates(res,nn)
 results['poisson']=estimates(sm.GLM(y,X,family=sm.families.Poisson()).fit(cov_type='HC0'),NAMES)
 results['firth'],results['firth_diagnostics']=firth(X,y)
 results['ml_three_step'],results['ml_three_step_diagnostics']=ml_three_step(d,f,Z,X,y)
 X2=np.delete(X,5,axis=1);X2[:,4]=(d.age>=4).astype(int)
 names2=NAMES.copy();names2.pop(5);names2[4]='Age categories 4-6 vs 1-3'
 results['two_age_logit']=estimates(sm.Logit(y,X2).fit(disp=0),names2)
 results['two_age_poisson']=estimates(sm.GLM(y,X2,family=sm.families.Poisson()).fit(cov_type='HC0'),names2)
 results['age_event_counts']={int(k):{'n':int((d.age==k).sum()),'events':int(d.loc[d.age==k,'injury'].sum())} for k in sorted(d.age.unique())}
 results['class_summary']=[]
 for c in range(3):
  m=cls==c;results['class_summary'].append({'n':int(m.sum()),'events':int(y[m].sum()),'ebi_mean':float(ebi[m].mean()),'ebi_sd':float(ebi[m].std(ddof=1)),'posterior_ebi':float(np.average(ebi,weights=f['tau'][:,c]))})
 results['pca_variance']=float(PCA().fit((d[['frequency','duration','distance']]-d[['frequency','duration','distance']].mean())/d[['frequency','duration','distance']].std(ddof=0)).explained_variance_ratio_[0])
 results['components']=estimates(sm.Logit(y,np.column_stack([np.ones(len(d)),d[['frequency','duration','distance']],X[:,2:]])).fit(disp=0),['Intercept','Frequency','Duration','Distance']+NAMES[2:])
 # Non-overlapping alternative: frequency plus duration / frequency plus distance.
 results['alternative_indices']={}
 for j,label in [(1,'frequency_duration'),(2,'frequency_distance')]:
  alt=100*(e[:,0]+e[:,j])/2;xx=X.copy();xx[:,1]=alt/10
  results['alternative_indices'][label]=estimates(sm.Logit(y,xx).fit(disp=0),NAMES)['EBI per 10']
 results['observed_response_patterns']=len(np.unique(a,axis=0))
 results['response_cells']=int(np.prod(LEVELS))
 from scipy.stats import ttest_ind, f as fdist, chi2_contingency
 from statsmodels.stats.multitest import multipletests
 from statsmodels.stats.proportion import proportion_confint
 results['poisson_models']={}
 for label,xx,nn in [('Model 1',X[:,:2],NAMES[:2]),('Model 2',X[:,:4],NAMES[:4]),('Model 3',X,NAMES)]:
  results['poisson_models'][label]=estimates(sm.GLM(y,xx,family=sm.families.Poisson()).fit(cov_type='HC0'),nn)
 results['sensitivity']={}
 pc=PCA(n_components=1).fit_transform((d[['frequency','duration','distance']]-d[['frequency','duration','distance']].mean())/d[['frequency','duration','distance']].std(ddof=0)).ravel()
 if np.corrcoef(pc,ebi)[0,1]<0:pc=-pc
 xx=X.copy();xx[:,1]=pc/pc.std(ddof=0)
 results['sensitivity']['PCA']=estimates(sm.Logit(y,xx).fit(disp=0),['Intercept','PC1 per SD']+NAMES[2:])
 prepared=np.column_stack([2-d[ITEMS[0]],2-d[ITEMS[1]]]+[(4-d[col])/3 for col in ITEMS[2:7]]+[d.training.map({1:1,2:0,3:.5})]).mean(1)*100
 xx=np.column_stack([X[:,:2],prepared/10,X[:,4:]])
 results['sensitivity']['continuous_preparedness']=estimates(sm.Logit(y,xx).fit(disp=0),['Intercept','EBI per 10','Preparedness per 10']+NAMES[4:])
 xx=np.column_stack([X,d.running]);results['sensitivity']['running']=estimates(sm.Logit(y,xx).fit(disp=0),NAMES+['Running'])
 m=(d.hiking+d.mountaineering)>0;results['sensitivity']['trail']=estimates(sm.Logit(y[m],X[m]).fit(disp=0),NAMES)
 m=y==1;yy=(d.injury_episodes[m]>=2).astype(int);results['sensitivity']['recurrent']=estimates(sm.Logit(yy,X[m,:4]).fit(disp=0),NAMES[:4])
 base=sm.Logit(y,X).fit(disp=0);xx=np.column_stack([X,(ebi/10)**2]);quadratic=sm.Logit(y,xx).fit(disp=0)
 results['quadratic_p']=float(chi2.sf(2*(quadratic.llf-base.llf),1))
 xx=np.column_stack([X,(ebi/10)*(cls==0),(ebi/10)*(cls==1)]);inter=sm.Logit(y,xx).fit(disp=0)
 results['interaction_p']=float(chi2.sf(2*(inter.llf-base.llf),2))
 quart=pd.qcut(ebi,4,labels=False);xx=np.column_stack([np.ones(len(d)),quart==1,quart==2,quart==3,X[:,2:]])
 results['quartiles']=estimates(sm.Logit(y,xx).fit(disp=0),['Intercept','Q2 vs Q1','Q3 vs Q1','Q4 vs Q1']+NAMES[2:])
 groups=[ebi[cls==c] for c in range(3)];nn=np.array([len(g) for g in groups]);mm=np.array([g.mean() for g in groups]);vv=np.array([g.var(ddof=1) for g in groups]);weights=nn/vv
 grand=np.sum(weights*mm)/weights.sum();u=np.sum((1-weights/weights.sum())**2/(nn-1));welch=np.sum(weights*(mm-grand)**2)/2/(1+u/4);df2=8/(3*u)
 results['welch']={'F':welch,'df1':2,'df2':df2,'p':fdist.sf(welch,2,df2)}
 rng2=np.random.default_rng(20261104);pairs=[]
 for c1,c2 in [(0,1),(0,2),(1,2)]:
  x1,x2=groups[c1],groups[c2];bmean=x1[rng2.integers(len(x1),size=(20000,len(x1)))].mean(1)-x2[rng2.integers(len(x2),size=(20000,len(x2)))].mean(1)
  pairs.append({'contrast':[c1,c2],'difference':x1.mean()-x2.mean(),'ci':np.quantile(bmean,[.025,.975]),'p':ttest_ind(x1,x2,equal_var=False).pvalue})
 for p,adj in zip(pairs,multipletests([p['p'] for p in pairs],method='holm')[1]):p['holm_p']=adj
 results['coupling_pairs']=pairs
 for c,g in enumerate(results['class_summary']):g['injury_wilson']=proportion_confint(g['events'],g['n'],method='wilson')
 results['injury_class_p']=chi2_contingency(pd.crosstab(cls,y),correction=False).pvalue
 # Bivariate Pearson residual diagnostic. Sparse expected counts limit calibration.
 tests=[];offs=np.cumsum([0]+LEVELS)
 for j in range(8):
  for l in range(j+1,8):
   expected=len(d)*np.einsum('c,ci,cj->ij',f['pi'],f['theta'][:,offs[j]:offs[j+1]],f['theta'][:,offs[l]:offs[l+1]])
   observed=np.zeros_like(expected);np.add.at(observed,(a[:,j],a[:,l]),1)
   stat=np.sum((observed-expected)**2/np.maximum(expected,1e-10));p=chi2.sf(stat,(LEVELS[j]-1)*(LEVELS[l]-1));tests.append({'items':[ITEMS[j],ITEMS[l]],'statistic':stat,'p':p})
 for p,adj in zip(tests,multipletests([p['p'] for p in tests],method='holm')[1]):p['holm_p']=adj
 results['bivariate_residuals']=tests
 results['three_four_cross_tab']=pd.crosstab(cls,fits[4]['labels']).to_numpy()
 cl4=fits[4]['labels'];X4=np.column_stack([Z[:,:2],cl4==0,cl4==1,cl4==2,Z[:,2:]])
 names4=NAMES[:2]+['Class 1 vs 4','Class 2 vs 4','Class 3 vs 4']+NAMES[4:]
 results['four_class_logit']=estimates(sm.Logit(y,X4).fit(disp=0),names4)
 results['four_class_poisson']=estimates(sm.GLM(y,X4,family=sm.families.Poisson()).fit(cov_type='HC0'),names4)
 results['four_class_summary']=[{'n':int((cl4==c).sum()),'events':int(y[cl4==c].sum()),'ebi_mean':float(ebi[cl4==c].mean())} for c in range(4)]
 def save(): (out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2,default=jsondefault),encoding='utf-8')
 save(); print('REGRESSIONS',json.dumps({k:results[k].get('EBI per 10') for k in ['poisson','firth','ml_three_step']},default=jsondefault),flush=True)
 # Parametric bootstrap LRT; fit both models to each replicate under k-1.
 for k in range(2,6):
  key=str(k);cache=out/f'blrt_{k}.json'
  if cache.exists():
   results.setdefault('blrt',{})[k]=json.loads(cache.read_text());save();continue
  null=fits[k-1];rng=np.random.default_rng(67004+k);obs=2*(fits[k]['ll']-null['ll']);stats=[];fail=0;t=time.time()
  offs=np.cumsum([0]+LEVELS)
  for b in range(args.blrt):
   latent=rng.choice(k-1,size=len(d),p=null['pi']);sim=np.empty_like(a)
   for j,c in enumerate(LEVELS):
    prob=null['theta'][latent,offs[j]:offs[j+1]]
    sim[:,j]=(rng.random(len(d))[:,None]>np.cumsum(prob,axis=1)).sum(1).clip(max=c-1)
   f0=lca(sim,k-1,starts=args.bootstrap_starts,seed=100000*k+b,maxiter=3000,tol=1e-6,initial=(null['theta'],null['pi']))
   # An exactly duplicated component embeds the fitted null in the alternative.
   th=np.vstack([f0['theta'],f0['theta'][-1]]);pi=np.r_[f0['pi'],f0['pi'][-1]/2];pi[-2]/=2
   f1=lca(sim,k,starts=args.bootstrap_starts,seed=200000*k+b,maxiter=3000,tol=1e-6,initial=(th,pi))
   if not f0['converged'] or not f1['converged']:fail+=1
   stats.append(max(0.,2*(f1['ll']-f0['ll'])))
   if (b+1)%20==0:print('BLRT',k,b+1,'elapsed',round(time.time()-t),flush=True)
  exceed=int(np.sum(np.array(stats)>=obs));p=(exceed+1)/(args.blrt+1)
  result={'observed_LR':obs,'p':p,'exceedances':exceed,'B':args.blrt,'starts':args.bootstrap_starts,'nonconverged_pairs':fail,'statistics':stats,'seed':67004+k}
  cache.write_text(json.dumps(result),encoding='utf-8');results.setdefault('blrt',{})[k]=result;save()
 print('COMPLETE',out,flush=True)
if __name__=='__main__': main()
