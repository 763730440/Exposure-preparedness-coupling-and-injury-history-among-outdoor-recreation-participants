# V10 supplementary reproducibility package

Supplementary Data S1: analysis_data.csv (220 rows). Supplementary Code S1: analysis_v10.py.
No names, contacts, locations, free text or original serial numbers are included.
BMI is retained as an analytical measure; original height and weight are omitted.
Version: V10. The analytical dataset and analysis code are publicly shared through
the GitHub repository:
https://github.com/763730440/Exposure-preparedness-coupling-and-injury-history-among-outdoor-recreation-participants

Distribution archive: fuxian.zip. No DOI has been assigned. This release updates
the package documentation and script naming; the analytical data, executable
analysis logic and saved numerical results are unchanged.

## Run
Download fuxian.zip from the repository and extract all files into one folder.
Python 3.12.14 was used. Install requirements.txt and run:
python analysis_v10.py --data analysis_data.csv --out reproduced --blrt 199

The script regenerates one- through five-class LCA, model enumeration, all regression
checks, pairwise exposure comparisons, component correlations and BLRT statistics.
All observations are real supplied study observations; none were simulated for the
analysis dataset. Only the null distributions for BLRTs were parametrically simulated.
Bootstrap BLRT random seeds are 67004+k. Observed-data LCA seeds are 20261104+k.
Main data LCA uses 120 starts; BLRT fits use 20 starts and 199 replicates per comparison.
Iterations stop at absolute log-likelihood changes below 1e-7 (observed data) or
1e-6 (BLRT), with caps of 4000 and 3000. Best log-likelihood repetitions use 1e-4.
LCA models use full categorical responses and local independence; 1e-12 expected-count
floors avoid log-zero computations. Labels are ordered after fitting by average
high-preparedness response probability, and high dichotomization is for display only.
The ML three-step model fixes the assignment-error matrix and jointly fits class
membership and outcome conditional on Model 3 non-class covariates (26 parameters).
Its standard errors are conditional on the first-step estimates, not a full bootstrap.
Firth intervals use profile penalized likelihood. Poisson PR intervals use HC0 robust
sandwich variance. Other ORs use Wald intervals. LMR-LRT is not implemented.

## Codebook
sex: 1 male, 2 female.
age: 1=<20, 2=20-30, 3=30-40, 4=40-50, 5=50-60, 6=>60 (original questionnaire labels).
Main age contrasts: codes 4-5 vs 1-3 and code 6 vs 1-3.
Two-group sensitivity contrast: codes 4-6 vs 1-3. These combine selected response
categories rather than reconstructing exact age boundaries.
bmi: kg/m^2 from self-reported height and weight.
occupation: 1 student, 2 public institution, 3 enterprise, 4 freelance, 5 retired, 6 other; descriptive only.
hiking, mountaineering, running, cycling, ball_sports, other_activity: 0 no, 1 yes; multiple selection.
frequency: 1 <=1/month, 2=2-3/month, 3=1-2/week, 4=3-4/week, 5 >=5/week.
duration: 1 <=1h, 2=1-3h, 3=3-5h, 4 >5h.
distance: 1 <=5km, 2=5-10km, 3=10-15km, 4=15-20km, 5 >=20km.
experience: 1 <1yr, 2=1-3yr, 3=3-5yr, 4=5-10yr, 5 >=10yr.
injury: 1 yes, 0 no, recalled for the preceding three years.
injury_episodes: 1 one, 2 two-three, 3 four-five, 4 >five; blank if injury=0 (skip pattern).
annual_exam, consultation: 1 yes, 2 no.
equipment, planning, weather, supplies: 1 every time, 2 often, 3 occasionally, 4 almost never.
knowledge: 1 very, 2 fairly, 3 some, 4 not very knowledgeable.
training: 1 yes, 2 no, 3 plan to.

Category boundaries follow the analytical coding and do not encode exact activity
quantities. Recruitment notices explicitly invited people aged 18-65 years to respond.
The questionnaire retained the six age categories listed above and contained no separate
exact-age screening item. The 18-65-year range is a recruitment eligibility requirement;
compliance cannot be independently verified from the recorded categories.
Recruitment used Wenjuanxing QR codes displayed at mountain/hiking entrances in Suzhou
and shared in WeChat groups for outdoor recreation enthusiasts. Eligibility included consent,
the stated recruitment age requirement of 18-65 years, at least one in-scope outdoor activity in the prior
12 months, and independent questionnaire completion. Eligibility requirements were displayed
on signs beside entrance QR codes and explicitly reiterated in WeChat recruitment messages;
only eligible individuals were invited to complete the questionnaire. Respondent-level recruitment channel,
pre-export screening counts and exact exposure times are unavailable in the analytical export.
